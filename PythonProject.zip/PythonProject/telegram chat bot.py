import telebot
import json
from telebot import types


TOKEN = "7613891899:AAF9QNy5PI2kb9jWzObF9Lb_9BYPUZxyFTk"
bot = telebot.TeleBot(TOKEN)


with open("data.json", "r", encoding="utf-8") as file:
    keyword_data = json.load(file)

def get_response(user_input, data):
    for keyword, response in data.items():
        if keyword.lower() in user_input.lower():
            return response
    return "🏁 Sorry, I don't have information on that yet."


@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    welcome_text = (
        "🏎️ *Welcome to the Formula 1 Chatbot!*\n"
        "Ask me about:\n"
        "- Drivers (e.g., Verstappen)\n"
        "- Teams (e.g., Mercedes)\n"
        "- Grand Prix schedule\n"
        "- Tracks and more!\n\n"
        "Use the buttons below or type a keyword."
    )
    markup = types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
    buttons = ["Drivers", "Teams", "Schedule", "Tracks"]
    markup.add(*[types.KeyboardButton(btn) for btn in buttons])
    bot.send_message(message.chat.id, welcome_text, parse_mode='Markdown', reply_markup=markup)


@bot.message_handler(func=lambda message: True)
def handle_message(message):
    user_input = message.text
    response = get_response(user_input, keyword_data)
    bot.send_message(message.chat.id, response)
bot.polling()
